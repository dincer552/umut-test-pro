rem Register Com Handler as DLL
cd /d "%~dp0"

set regsvr=%SystemRoot%\SysWow64\regsvr32.exe
set REGOPT=/s

RainbowComHandler.exe /UnregServer
%regsvr% /u /s RainbowComHandlerPS.dll

%regsvr% %REGOPT% RainbowComHandler.dll
