@echo ----  Registrierung der Kommunikationskomponenten  ----
cd /d "%~dp0"
@echo off
rem %0: executing batch file incl. dir and drive
rem %~dp0: d=drive p=path

rem set REGOPT=/s

rem ::: on a 64-bit system, we register our components as 32-bit components using the 32-bit variant
rem ::: of the %regsvr%32 tool, located in SysWow64. The 64-bit variant is located under System32. Don't be
rem ::: confused of this, its right :-)
set regsvr=%SystemRoot%\SysWow64\regsvr32.exe

@echo on
%regsvr% %REGOPT% RainbowApplicationSrv.dll
%regsvr% %REGOPT% RainbowObjectHandlerSrv.dll
%regsvr% %REGOPT% RainbowIPComSrv.dll
%regsvr% %REGOPT% RainbowSerialSrv.dll
%regsvr% %REGOPT% RainbowKonnexSrv.dll
%regsvr% %REGOPT% RainbowLocalSrv.dll
%regsvr% %REGOPT% RainbowLonSrv.dll
%regsvr% %REGOPT% RainbowUsbSrv.dll

rem %regsvr% %REGOPT% RainbowComHandler.dll
RainbowComHandler.exe /RegServer
%regsvr% %REGOPT% RainbowComHandlerPS.dll

RainbowWeb.exe /RegServer
%regsvr% %REGOPT% RainbowWebPS.dll
