rem Register Com Handler as EXE
cd /d "%~dp0"

set regsvr=%SystemRoot%\SysWow64\regsvr32.exe
set REGOPT=/s

%regsvr% %REGOPT% /u RainbowComHandler.dll

RainbowComHandler.exe /RegServer
%regsvr% %REGOPT% RainbowComHandlerPS.dll
